/**
  ******************************************************************************
  * @file    iot_alios.h
  * @version V1.0
  * @date
  ******************************************************************************
  * @attention
  *
  * COPYRIGHT(c) 2021 Shanghai XinMiaoLink Technology Co.,Ltd.
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  * 1. Redistributions of source code must retain the above copyright notice,
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. The name of the author may not be used to endorse or promote products
  *    derived from this software without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

#ifndef _IOT_ALIOS_H_
#define _IOT_ALIOS_H_

#ifdef __cplusplus
extern "C" {
#endif


#define IOT_ALIOS_SDK_VERSION "2.0.2-20220914"

#define IOT_SUCCESS 0
#define IOT_FAIL 1


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include "hal/wifi.h"


enum IOT_MODULE_TYPE
{
	IOT_MODULE_XC13SL=0x10,
	IOT_MODULE_XC13SG,
	IOT_MODULE_XC13SM,
	IOT_MODULE_XC15P
};

enum IOT_SYS_EVENT_ID
{
	IOT_EVENT_WIFI_CONNECTED=0,
	IOT_EVENT_WIFI_DISCONNECTED=1,
	IOT_EVENT_CLOUD_CONNECTED,
	IOT_EVENT_CLOUD_DISCONNECTED,
	IOT_EVENT_AWSS_START,
	IOT_EVENT_AWSS_AP_START,
	IOT_EVENT_AWSS_BLE_START,
	IOT_EVENT_AWSS_SUCCESS,
	IOT_EVENT_AWSS_TIMEOUT,
	IOT_EVENT_DEVICE_UNBIND,
	IOT_EVENT_OTA_STATE_START=0x10,
	IOT_EVENT_OTA_STATE_SUCCESS,
	IOT_EVENT_OTA_STATE_FAIL,
	IOT_EVENT_NTP_TIME_UPDATE=0x20
};

enum IOT_AWSS_MODE_TYPE
{
	IOT_AWSS_MODE_DEFAULT=0,
	IOT_AWSS_MODE_AWSS=1,
	IOT_AWSS_MODE_AP,
	IOT_AWSS_MODE_BLE,
	IOT_AWSS_MODE_NONE
};

typedef int (*iot_sys_event_callback_t)(enum IOT_SYS_EVENT_ID event_id, void *param);

typedef int (*data_callback_t)(void *data, uint32_t len);

typedef struct
{
}at_session_t,*pat_session_t;

typedef struct
{
	const char * name;
	int	(*func)(pat_session_t,int, char** ,char *,int);
	const char * doc;
	int	(*callhook)(pat_session_t,int, char** ,char *,int);
} iot_at_cmd_t,*p_iot_at_cmd_t;

typedef struct
{
	uint8_t addr_type;
	uint8_t addr[6];
	int8_t rssi;
	uint8_t evtype;
	uint16_t len;
	uint8_t *data;

}IOT_BLE_SCAN_RESULT_ITEM;

typedef int (*iot_ble_scan_callback_t)(IOT_BLE_SCAN_RESULT_ITEM *);


int iot_alios_init(void);

int iot_alios_wifi_init(void);

int iot_alios_wifi_get_mac_address(unsigned char *mac);

int iot_alios_ble_get_mac_address(unsigned char *mac);

int iot_alios_flash_check_protect(unsigned int addr);

int iot_alios_uart_task_start(data_callback_t data_callback, p_iot_at_cmd_t cmd_table);

int iot_alios_uart_send(unsigned char *data, int len);

int iot_alios_check_awss_state(void);

int iot_alios_awss_is_start(void);

int iot_alios_check_net_state(void);

int iot_alios_net_start_assis(void);

int iot_alios_ota_init(void);

int iot_alios_send_event(enum IOT_SYS_EVENT_ID event_id, void *param);

int iot_alios_register_event(iot_sys_event_callback_t p_callback);

int iot_alios_powersave_is_enable(void);


/**
 * @brief check is in command mode.
 *
 * @param[in] none
 * @return[out] 1-in command mode, 0-not in command mode
 * @see None.
 * @note None.
 */
int iot_alios_uart_in_cmd_mode(void);

/**
 * @brief send uart data.
 *
 * @param[in] data: send data
 *			 len: the length of data, in bytes
 * @return[out] the data length of send success, -1 is send fail
 * @see None.
 * @note not work in command mode, can use function 'iot_alios_uart_send'.
 */
int iot_alios_uart_send_data(unsigned char *data, int len);

/**
 * @brief get alios product key.
 *
 * @param[in] none
 * @return[out] product key
 * @see None.
 * @note None.
 */
char *iot_alios_get_product_key(void);

/**
 * @brief get alios product secret.
 *
 * @param[in] none
 * @return[out] product secret
 * @see None.
 * @note None.
 */
char *iot_alios_get_product_secret(void);

/**
 * @brief get alios product id.
 *
 * @param[in] none
 * @return[out] product id
 * @see None.
 * @note None.
 */
unsigned int iot_alios_get_product_id(void);

/**
 * @brief get alios device name.
 *
 * @param[in] none
 * @return[out] device name
 * @see None.
 * @note None.
 */
char *iot_alios_get_device_name(void);

/**
 * @brief get alios device secret.
 *
 * @param[in] none
 * @return[out] device secret
 * @see None.
 * @note None.
 */
char *iot_alios_get_device_secret(void);

/**
 * @brief get hostname(MID).
 *
 * @param[in] none
 * @return[out] hostname
 * @see None.
 * @note None.
 */
char *iot_alios_get_hostname(void);

/**
 * @brief reset device and start awss.
 *
 * @param[in] type: awss type
 * @return[out] IOT_SUCCESS-successfully, other value is failed
 * @see None.
 * @note None.
 */
int iot_alios_reset_start_awss(enum IOT_AWSS_MODE_TYPE type);


typedef int (*wifi_scan_callback_t)(ap_list_adv_t *);

/**
 * @brief wifi scan.
 *
 * @param[in] cb: pass ssid info(scan result) to this callback one by one
 * @return[out] the number of wifi
 * @see None.
 * @note None.
 */
int iot_alios_wifi_scan(wifi_scan_callback_t cb);


#ifdef __cplusplus
}
#endif

#endif/* _IOT_ALIOS_H_ */

